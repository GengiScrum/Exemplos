export class NDDTitlebarGlobalConfig {
    public closeIcon: string;
}
