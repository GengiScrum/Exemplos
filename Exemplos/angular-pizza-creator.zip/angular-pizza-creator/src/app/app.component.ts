import { Component } from '@angular/core';

@Component({
  selector: 'ndd-app',
  templateUrl: './app.component.html',
})
export class AppComponent {}
