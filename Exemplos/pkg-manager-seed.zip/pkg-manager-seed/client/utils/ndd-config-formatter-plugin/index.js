module.exports = require('./ndd-config-formatter-plugin');
