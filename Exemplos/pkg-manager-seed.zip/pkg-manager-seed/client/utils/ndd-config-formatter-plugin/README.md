# ndd-config-formatter-plugin

 Plugin para formatar o arquivo de configuração.

 Esse plugin tem por responsabilidade remover as hashs do bundle de configuração dos projetos.

 Ele também remove o webpackBootstrap (boilerplate) adicionado pelo webpack no bundle.