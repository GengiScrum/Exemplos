export enum Topping {
}

export enum PizzaSizes {
}
