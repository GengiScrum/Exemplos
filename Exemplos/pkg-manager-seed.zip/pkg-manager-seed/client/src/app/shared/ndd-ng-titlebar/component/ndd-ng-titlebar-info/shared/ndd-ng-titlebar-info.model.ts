export interface INDDTitlebarInfoItem {
    value: string;
    description: string;
}
