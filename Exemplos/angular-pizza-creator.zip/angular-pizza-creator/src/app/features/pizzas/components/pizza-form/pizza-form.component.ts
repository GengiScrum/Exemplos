import { Component, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'pizza-form',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: 'pizza-form.component.html',
})
export class PizzaFormComponent {
}
