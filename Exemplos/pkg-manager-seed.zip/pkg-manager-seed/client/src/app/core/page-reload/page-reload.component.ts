import { Component } from '@angular/core';

@Component({
    selector: 'ndd-page-reload',
    templateUrl: 'page-reload.component.html',
})
export class PageReloadComponent { }
