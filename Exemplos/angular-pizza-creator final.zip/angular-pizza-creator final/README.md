# Repositório de exemplos

Repositório de exemplo para realização dos exercícios da 5º academia do programador.

## Instruções

Para baixar os exemplos, utilize o comando abaixo:

```
    git clone https://tfs.ndd.com.br/tfs/AcademyCollection/Academia-Programador-2018/_git/Exemplos
```
