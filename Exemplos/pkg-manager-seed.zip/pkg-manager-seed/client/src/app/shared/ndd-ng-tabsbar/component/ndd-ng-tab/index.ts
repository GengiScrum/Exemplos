export * from './ndd-ng-tab.component';
