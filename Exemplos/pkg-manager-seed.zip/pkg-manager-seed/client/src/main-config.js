// ## Start Config File

var config = {
    apiEndpoint: API_URL,
    apiResourcesEndpoint: API_URL + 'api/i18n/',
}

localStorage.setItem('NDDResearchConfig', JSON.stringify(config));

//## End Config File