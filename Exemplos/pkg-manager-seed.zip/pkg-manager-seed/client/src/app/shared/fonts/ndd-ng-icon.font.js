module.exports = {
    files: [
        './icons/*.svg'
    ],
    fontName: 'nddFontIcon',
    classPrefix: 'ndd-font-',
    baseClass: 'ndd-font'
};