import { InjectionToken } from '@angular/core';

export let KENDO_TOKEN: InjectionToken<any> = new InjectionToken<any>('kendo-ui');
