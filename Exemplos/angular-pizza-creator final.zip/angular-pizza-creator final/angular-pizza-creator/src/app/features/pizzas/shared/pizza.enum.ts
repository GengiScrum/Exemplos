export enum Toppings {
  Anchovu = 'anchovy',
  Bacon = 'bacon',
  Basil = 'basil',
  Chili = 'chili',
  Mozzarella = 'mozzarella',
  Mushroom = 'mushroom',
  Olive = 'olive',
  Onion = 'onion',
  Pepper = 'pepper',
  Pepperoni = 'pepperoni',
  Sweetcorn = 'sweetcorn',
  Tomato = 'tomato',
}

export enum PizzaSizes {
  Small = 'small',
  Medium = 'medium',
  Large = 'large',
}
