import { Topping } from './pizza.enum';

export class Toppings {
  public static readonly ALL_TOPPINGS: Topping[] = [];
}

export class Pizza {
}
